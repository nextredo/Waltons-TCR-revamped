/*    Mock AVR environment used when compiling to JavaScript with Emscripten.        (Only used by private tests and tools.)*/

#ifndef INTERRUPT_H_
#define INTERRUPT_H_

#include "common.h"

#endif /* INTERRUPT_H_ */