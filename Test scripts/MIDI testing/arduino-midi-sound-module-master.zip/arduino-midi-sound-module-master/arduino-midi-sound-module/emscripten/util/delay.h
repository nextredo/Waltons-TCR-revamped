/*    Mock AVR environment used when compiling to JavaScript with Emscripten.        (Only used by private tests and tools.)*/

static void _delay_ms(double __ms) { }